package com.maxis_technology.commonutils;

import android.content.Context;

public class ApiUtils {

    private String auth_token;

    public String urlForFood;
    public String urlForCustomerOrder;
    public String urlForOrderPost;
    public String urlForProfileEdit;
    public String urlForPostNewCustomer;
    public String urlForUserLogin;
    public String urlForAdImage;
    public String urlForChangePassword;

    private final String basePath = "http://jnahian.com/bk/api/";

    public ApiUtils(Context context) {
        PreferenceData preferenceData = new PreferenceData(context);
        auth_token = preferenceData.getStringValue(ConstantValues.AUTHENTICATION_KEY);
        init();
    }

    private void init() {
        urlForFood  = basePath + "foods";
        urlForCustomerOrder = basePath + "customer/"+ auth_token + "/orders";
        urlForOrderPost  = basePath + "customer/" + auth_token + "/order/store";
        urlForProfileEdit  = basePath + "customer/" + auth_token + "/update";
        urlForPostNewCustomer  = basePath + "customer/store";
        urlForUserLogin  = basePath + "customer/login";
        urlForChangePassword = basePath + "customer/" + auth_token + "/change-password";
        urlForAdImage = basePath + "ads/1";
    }


}
