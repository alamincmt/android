package com.maxis_technology.api;

import android.content.Context;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.maxis_technology.commonutils.ApiUtils;

import java.util.Map;

public class ApiWrapper {
    private Context context;
    ApiUtils apiUtils;
    Response.ErrorListener errorListener;

    public ApiWrapper(Context context) {
        this.context = context;
        apiUtils = new ApiUtils(context);
        errorListener = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        };
    }

    public void getJsonForFood(Response.Listener<String> listener){
        StringRequest request = new StringRequest(Request.Method.GET, apiUtils.urlForFood , listener, errorListener);
        AppController.getmInstance().addToRequestQueue(request);
    }

    public void postOrder(Response.Listener<String> listener, final Map<String, String> params){
        StringRequest request = new StringRequest(Request.Method.POST, apiUtils.urlForOrderPost , listener, errorListener){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                return params;
            }
        };
        AppController.getmInstance().addToRequestQueue(request);
    }

    public void userLogin(Response.Listener<String> listener, final Map<String, String> params){
        StringRequest request = new StringRequest(Request.Method.POST, apiUtils.urlForUserLogin , listener, errorListener){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                return params;
            }
        };
        AppController.getmInstance().addToRequestQueue(request);
    }

    public void postNewCustomer(Response.Listener<String> listener, final Map<String, String> params){
        StringRequest request = new StringRequest(Request.Method.POST, apiUtils.urlForPostNewCustomer , listener, errorListener){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                return params;
            }
        };
        AppController.getmInstance().addToRequestQueue(request);
    }
}
