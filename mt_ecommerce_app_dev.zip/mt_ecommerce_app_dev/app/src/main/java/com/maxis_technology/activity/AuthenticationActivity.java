package com.maxis_technology.activity;

import android.content.Intent;
import android.os.Bundle;

import com.maxis_technology.R;
import com.maxis_technology.callback.Communicator;
import com.maxis_technology.fragments.LoginFragment;
import com.maxis_technology.fragments.SignUpFragment;

public class AuthenticationActivity extends BaseActivity implements Communicator {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_authentication);

        Intent intent = getIntent();
        String fragmentToShow = intent.getStringExtra("fragment");

        communicate(fragmentToShow);
    }

    @Override
    public void communicate(String response) {
        if (response != null && response.equals("login")){
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new LoginFragment(), null).commit();
        }else if (response != null && response.equals("signup")){
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new SignUpFragment(), null).commit();
        }
    }

}
