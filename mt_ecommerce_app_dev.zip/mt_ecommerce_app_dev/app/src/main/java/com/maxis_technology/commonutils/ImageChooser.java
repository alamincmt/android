package com.maxis_technology.commonutils;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;

public class ImageChooser {

    private final int ACTION_CAMERA = 1000;
    private final int ACTION_GALLERY = 1001;


    private Activity context;
    public Uri uri;
    private Uri imageName;


    public ImageChooser(Activity context) {
        this.context = context;
    }

    public void choose() {
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case DialogInterface.BUTTON_POSITIVE:
                        imageName = Uri.parse(Environment.getExternalStorageDirectory() + "/" + System.currentTimeMillis());
                        Intent takePhoto = new Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT, imageName);
                        context.startActivityForResult(takePhoto, ACTION_CAMERA);
                        break;

                    case DialogInterface.BUTTON_NEGATIVE:
                        Intent takePhotoGallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                        context.startActivityForResult(takePhotoGallery, ACTION_GALLERY);
                        break;
                }
            }
        };

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage("Take a photo").setPositiveButton("Camera", dialogClickListener)
                .setNegativeButton("Gallery", dialogClickListener).show();
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data, OnImageChosen onImageChosen) {
        switch (requestCode) {
            case ACTION_CAMERA:
                if (resultCode == context.RESULT_OK) {
                    uri = data.getData();
                    onImageChosen.onChosen(uri);
                }
                break;
            case ACTION_GALLERY:
                if (resultCode == context.RESULT_OK) {
                    uri = data.getData();
                    onImageChosen.onChosen(uri);
                }
        }
    }

    public interface OnImageChosen {
        void onChosen(Uri imageUri);
    }
}
