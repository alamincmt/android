package com.maxis_technology.activity;

import android.app.SearchManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Response;
import com.maxis_technology.adapters.FoodAdapter;
import com.maxis_technology.api.ApiWrapper;
import com.maxis_technology.commonutils.Utils;
import com.maxis_technology.R;
import com.maxis_technology.model.CartItem;
import com.maxis_technology.model.FoodItem;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Context context;
    private FoodAdapter foodAdapter;
    private List<FoodItem> foodList = new ArrayList<FoodItem>();
    private RecyclerView rcvFood;
    ApiWrapper apiWrapper;
    Utils utils;

    private SearchView searchView;

    SwipeRefreshLayout swipeRefreshLayout;
    BroadcastReceiver cartItemCountReceiver;

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.context = MainActivity.this;
        this.utils = new Utils(context);
        apiWrapper = new ApiWrapper(MainActivity.this);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipe_refresh_food_list);
        rcvFood = (RecyclerView) findViewById(R.id.rcv_food);
        foodAdapter = new FoodAdapter(MainActivity.this, foodList);

        RecyclerView.LayoutManager rcvLayoutManager = new GridLayoutManager(context, 2);
        rcvFood.setLayoutManager(rcvLayoutManager);
        rcvFood.addItemDecoration(new GridSpacingItemDecoration(2, dpToPx(10), true));
        rcvFood.setItemAnimator(new DefaultItemAnimator());
        rcvFood.setAdapter(foodAdapter);


        if(utils.isNetworkAvailable()){
            populateFoodList();
        }else{
            utils.showToastLong("No internet connection. Please try again with active internet connection. ");
        }

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                foodList.clear();
                populateFoodList();
                swipeRefreshLayout.setRefreshing(false);
                foodAdapter.notifyDataSetChanged();
            }
        });
    }



    private void populateFoodList() {
        foodList.clear();
        apiWrapper.getJsonForFood(new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    prepareFoods(response);
                    if (swipeRefreshLayout != null && swipeRefreshLayout.isRefreshing()) {
                        swipeRefreshLayout.setRefreshing(false);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(final Menu menu) {
        RelativeLayout notifCount;
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
            getMenuInflater().inflate(R.menu.main, menu);
            MenuItem item = menu.findItem(R.id.badge);
            item.setActionView(R.layout.item_count_badge_layout);
            notifCount = (RelativeLayout) item.getActionView();
        }else{
            MenuItem item = menu.findItem(R.id.badge);
            MenuItemCompat.setActionView(item, R.layout.item_count_badge_layout);
            notifCount = (RelativeLayout) MenuItemCompat.getActionView(item);
        }

        final TextView tv = (TextView) notifCount.findViewById(R.id.actionbar_notifcation_textview);
        List<CartItem> itemCartList = utils.getCartItems();
        if(itemCartList != null && itemCartList.size() > 0){
            tv.setText(itemCartList.size() + "");
        }

        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Test Item Count", Toast.LENGTH_LONG).show();
                startActivity(new Intent(MainActivity.this, CartActivity.class));
            }
        });
        cartItemCountReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                // Get extra data included in the Intent
                Integer itemCount = intent.getIntExtra("itemCount", 0);
                Log.d("BroadCast Cart Item: ", "Item count: " + itemCount);

                tv.setText(itemCount + "");

            }
        };

        LocalBroadcastManager.getInstance(this).registerReceiver(cartItemCountReceiver,
                new IntentFilter("receive_cart_item_count"));

        if(Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP){
            getMenuInflater().inflate(R.menu.main, menu);
        }

        // Associate searchable configuration with the SearchView
        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        searchView = (SearchView) menu.findItem(R.id.action_search)
                .getActionView();
        searchView.setSearchableInfo(searchManager
                .getSearchableInfo(getComponentName()));
        searchView.setMaxWidth(Integer.MAX_VALUE);

        // listening to search query text change
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                // filter recycler view when query submitted
                foodAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String query) {
                // filter recycler view when text is changed
                foodAdapter.getFilter().filter(query);
                return false;
            }
        });

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public void onBackPressed() {
        // close search view on back button pressed
        if (!searchView.isIconified()) {
            searchView.setIconified(true);
            return;
        }
        super.onBackPressed();
    }

    /**
     * Adding few albums for testing
     */
    private void prepareFoods(String response) throws JSONException {

        JSONObject root = new JSONObject(response);
        int status = root.getInt("status");
        if (status != 200) {
            utils.showToastLong("No Items found!");
            return;
        }

        JSONObject jsonObject = root.getJSONObject("data");
        JSONArray foodData = jsonObject.getJSONArray("foods");
        for (int i = 0; i < foodData.length(); i++){
            JSONObject foodObject = (JSONObject) foodData.get(i);
            FoodItem foodItem = new FoodItem();
            foodItem.setFoodId(foodObject.getString("id"));
            foodItem.setFoodName(foodObject.getString("name"));
            foodItem.setFoodPrice(Double.valueOf(foodObject.getString("price")));
            foodItem.setFoodDetails(foodObject.getString("details"));
            String image = foodObject.isNull("photo")? null: foodObject.getString("photo");
            foodItem.setFoodThumbnail(image);

            foodList.add(foodItem);
        }

        foodAdapter.notifyDataSetChanged();
    }

    /**
     * Converting dp to pixel
     */
    private int dpToPx(int dp) {
        Resources r = getResources();
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, r.getDisplayMetrics()));
    }

    @Override
    protected void onDestroy() {
        // Unregister since the activity is about to be closed.
        LocalBroadcastManager.getInstance(this).unregisterReceiver(cartItemCountReceiver);
        super.onDestroy();
    }

    @Override
    protected void onPostResume() {
        if(!utils.isNetworkAvailable()){
            startActivity(new Intent(MainActivity.this, NetWorkConnectionErrorActivity.class));
        }
        super.onPostResume();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the HomeFragment/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if(item.getTitle().equals("Add To Cart")){
            startActivity(new Intent(MainActivity.this, CartActivity.class));
        }
        return super.onOptionsItemSelected(item);
    }



    /**
     * RecyclerView item decoration - give equal margin around grid item
     */
    public class GridSpacingItemDecoration extends RecyclerView.ItemDecoration {

        private int spanCount;
        private int spacing;
        private boolean includeEdge;

        public GridSpacingItemDecoration(int spanCount, int spacing, boolean includeEdge) {
            this.spanCount = spanCount;
            this.spacing = spacing;
            this.includeEdge = includeEdge;
        }

        @Override
        public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
            int position = parent.getChildAdapterPosition(view); // item position
            int column = position % spanCount; // item column

            if (includeEdge) {
                outRect.left = spacing - column * spacing / spanCount; // spacing - column * ((1f / spanCount) * spacing)
                outRect.right = (column + 1) * spacing / spanCount; // (column + 1) * ((1f / spanCount) * spacing)

                if (position < spanCount) { // top edge
                    outRect.top = spacing;
                }
                outRect.bottom = spacing; // item bottom
            } else {
                outRect.left = column * spacing / spanCount; // column * ((1f / spanCount) * spacing)
                outRect.right = spacing - (column + 1) * spacing / spanCount; // spacing - (column + 1) * ((1f /    spanCount) * spacing)
                if (position >= spanCount) {
                    outRect.top = spacing; // item top
                }
            }
        }
    }
}
