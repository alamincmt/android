package com.maxis_technology.callback;

public interface Communicator {

    public void communicate(String response);
}
