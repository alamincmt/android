package com.maxis_technology.model;

import java.io.Serializable;

public class FoodItem implements Serializable{
    private String foodId;
    private String foodName;
    private String foodDetails;
    private String foodThumbnail;
    private String restautantId;
    private Double foodPrice;

    public FoodItem() {

    }

    public FoodItem(String foodId, String foodName, String foodDetails, String foodThumbnail, String restautantId, Double foodPrice) {
        this.foodId = foodId;
        this.foodName = foodName;
        this.foodDetails = foodDetails;
        this.foodThumbnail = foodThumbnail;
        this.restautantId = restautantId;
        this.foodPrice = foodPrice;
    }

    public String getFoodId() {
        return foodId;
    }

    public FoodItem setFoodId(String foodId) {
        this.foodId = foodId;
        return this;
    }

    public String getFoodName() {
        return foodName;
    }

    public FoodItem setFoodName(String foodName) {
        this.foodName = foodName;
        return this;
    }

    public String getFoodDetails() {
        return foodDetails;
    }

    public FoodItem setFoodDetails(String foodDetails) {
        this.foodDetails = foodDetails;
        return this;
    }

    public String getFoodThumbnail() {
        return foodThumbnail;
    }

    public FoodItem setFoodThumbnail(String foodThumbnail) {
        this.foodThumbnail = foodThumbnail;
        return this;
    }

    public String getRestautantId() {
        return restautantId;
    }

    public FoodItem setRestautantId(String restautantId) {
        this.restautantId = restautantId;
        return this;
    }

    public Double getFoodPrice() {
        return foodPrice;
    }

    public FoodItem setFoodPrice(Double foodPrice) {
        this.foodPrice = foodPrice;
        return this;
    }
}
