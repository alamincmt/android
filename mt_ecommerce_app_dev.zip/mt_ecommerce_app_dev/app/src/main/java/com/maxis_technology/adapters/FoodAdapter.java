package com.maxis_technology.adapters;

import android.app.Activity;
import android.content.Intent;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import com.maxis_technology.activity.FoodDetailsActivity;
import com.maxis_technology.commonutils.AlertDialogUtils;
import com.maxis_technology.model.FoodItem;
import com.maxis_technology.R;
import com.maxis_technology.commonutils.Utils;
import com.maxis_technology.model.CartItem;

import java.util.ArrayList;
import java.util.List;

public class FoodAdapter extends RecyclerView.Adapter<FoodAdapter.MyViewHolder>  implements Filterable {

    private Activity activity;
    private List<FoodItem> foodList;
    private List<FoodItem> filteredFoodList;
    private List<CartItem> mCart = new ArrayList<CartItem>();
    private AlertDialogUtils alertDialogUtils;
    Utils utils;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView tvFoodName, tvFoodPrice;
        public ImageView imgvFoodThumbnail, imgvAddToCart;
        public CardView cvFoodCard;


        public MyViewHolder(View view) {
            super(view);
            tvFoodName = (TextView) view.findViewById(R.id.tv_food_name);
            tvFoodPrice = (TextView) view.findViewById(R.id.tv_food_price);
            imgvFoodThumbnail = (ImageView) view.findViewById(R.id.imgv_food_thumbmnail);
            imgvAddToCart = (ImageView) view.findViewById(R.id.imgv_add_to_card);
            cvFoodCard = (CardView) view.findViewById(R.id.cv_food_card);
        }
    }


    public FoodAdapter(Activity activity, List<FoodItem> foodList) {
        this.activity = activity;
        this.foodList = foodList;
        this.filteredFoodList = foodList;
        utils = new Utils(activity);
        alertDialogUtils = new AlertDialogUtils(activity);
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if (charString.isEmpty()) {
                    filteredFoodList = foodList;
                } else {
                    List<FoodItem> filteredList = new ArrayList<>();
                    for (FoodItem row : foodList) {

                        // name match condition. this might differ depending on your requirement
                        // here we are looking for name or phone number match
                        if (row.getFoodName().toLowerCase().contains(charString.toLowerCase())) {
                            filteredList.add(row);
                        }
                    }

                    filteredFoodList = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = filteredFoodList;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                filteredFoodList = (ArrayList<FoodItem>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.card_item_food, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {

        final FoodItem foodItem = filteredFoodList.get(position);
        holder.tvFoodName.setText(foodItem.getFoodName());
        holder.tvFoodPrice.setText(foodItem.getFoodPrice() + " BDT");
        utils.loadImageThumbnail(activity,holder.imgvFoodThumbnail,foodItem.getFoodThumbnail());
        // loading food cover image using Glide library
       // Glide.with(activity).load(food.getFoodThumbnail()).placeholder(R.drawable.food_image1).into(holder.imgvFoodThumbnail);

        holder.imgvAddToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                alertDialogUtils.showAddToCartItemChooserDialog(foodItem.getFoodName(), new OnCartItemCountChanged() {
                    @Override
                    public void onChange(int newCount) {
                        mCart = utils.getCartItems();
                        if (mCart == null) {
                            mCart = new ArrayList<CartItem>();
                        }

//                        CartItem cartItem = (CartItem) foodItem; // BARI KHAY KEN? :@
                        CartItem cartItem = new CartItem(foodItem);
                        cartItem.setQuantity(newCount)
                                .setFoodPrice(foodItem.getFoodPrice() * newCount);
                        mCart.add(cartItem);
                        utils.updateCart(mCart);

                        Intent intent = new Intent("receive_cart_item_count");
                        intent.putExtra("itemCount", utils.getCartItems().size());
                        LocalBroadcastManager.getInstance(activity).sendBroadcast(intent);
                    }
                });
            }
        });

        holder.cvFoodCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activity.startActivity(new Intent(activity, FoodDetailsActivity.class)
                        .putExtra("foodItem", filteredFoodList.get(position))
                        .putExtra("foodImage",foodList.get(position).getFoodThumbnail()));
                        /*.putExtra("foodId", foodList.get(position).getFoodId())
                        .putExtra("foodNameToShowDetails", foodList.get(position).getFoodName())
                        .putExtra("foodDtails",foodList.get(position).getFoodDetails())
                        .putExtra("foodImage",foodList.get(position).getFoodThumbnail())
                        .putExtra("foodPrice",foodList.get(position).getFoodPrice())
                        //.putExtra("foodQuantity",newCount)
                        .putExtra("orderID",foodList.get(position).getFoodPrice()));*/
            }
        });
    }

    @Override
    public int getItemCount() {
        return filteredFoodList.size();
    }

    public interface OnCartItemCountChanged{
        void onChange(int newCount);
    }

}
