package com.maxis_technology.model;

public class CartItem extends FoodItem {
    private int quantity;
    private String orderId;
    private String shippingAddress;

    public CartItem() {
    }

    public CartItem(FoodItem foodItem) {
        super(foodItem.getFoodId(),foodItem.getFoodName(),foodItem.getFoodDetails(),foodItem.getFoodThumbnail(),foodItem.getRestautantId(),foodItem.getFoodPrice());
    }

    public CartItem(String foodId, String foodName, String foodDetails, String foodThumbnail, String restautantId, Double foodPrice, int quantity, String orderId) {
        super(foodId, foodName, foodDetails, foodThumbnail, restautantId, foodPrice);
        this.quantity = quantity;
        this.orderId = orderId;
    }

    public int getQuantity() {
        return quantity;
    }

    public CartItem setQuantity(int quantity) {
        this.quantity = quantity;
        return this;
    }

    public String getOrderId() {
        return orderId;
    }

    public CartItem setOrderId(String orderId) {
        this.orderId = orderId;
        return this;
    }

    @Override
    public CartItem setFoodId(String foodId) {
        super.setFoodId(foodId);
        return this;
    }

    @Override
    public CartItem setFoodName(String foodName) {
        super.setFoodName(foodName);
        return this;
    }

    @Override
    public CartItem setFoodDetails(String foodDetails) {
        super.setFoodDetails(foodDetails);
        return this;
    }

    @Override
    public CartItem setFoodThumbnail(String foodThumbnail) {
        super.setFoodThumbnail(foodThumbnail);
        return this;
    }

    @Override
    public CartItem setRestautantId(String restautantId) {
        super.setRestautantId(restautantId);
        return this;
    }

    @Override
    public CartItem setFoodPrice(Double foodPrice) {
        super.setFoodPrice(foodPrice);
        return this;
    }
}
