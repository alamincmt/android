package com.maxis_technology.adapters;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.maxis_technology.commonutils.Utils;
import com.maxis_technology.R;
import com.maxis_technology.activity.CartActivity;
import com.maxis_technology.model.CartItem;
import com.bumptech.glide.Glide;

import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    final int TYPE_CART_ITEM = 1;
    final int TYPE_SHIPPING_ADDRESS = 2;

    CartActivity.OnAddressUpdated onAddressUpdated;

    private Context context;
    private List<CartItem> cartList;
    private Utils utils;
    private CartItem cart;
    TextView tvShippingAddress;
    String customerLocation;

    public class CartViewHolder extends RecyclerView.ViewHolder {
        public TextView tvFoodName, tvFoodPrice;
        public ImageView imgvFoodThumbnail;
        public TextView tvCartItemCount;
        public ImageView imgvCartItemPlus, imgvCartItemMinus;

        public CartViewHolder(View view) {
            super(view);
            tvFoodName = (TextView) view.findViewById(R.id.tv_add_to_cart_food_name);
            tvFoodPrice = (TextView) view.findViewById(R.id.tv_add_to_cart_food_price);
            imgvFoodThumbnail = (ImageView) view.findViewById(R.id.imgv_item_cart_image);
            tvCartItemCount = (TextView) view.findViewById(R.id.tv_add_to_cart_count);
            imgvCartItemPlus = (ImageView) view.findViewById(R.id.imgv_add_to_cart_count_plus);
            imgvCartItemMinus = (ImageView) view.findViewById(R.id.imgv_add_to_cart_count_minus);
        }
    }

    public CartAdapter(Context context, List<CartItem> cartList, CartActivity.OnAddressUpdated onAddressUpdated) {
        this.context = context;
        this.cartList = cartList;
        this.utils = new Utils(context);
        this.onAddressUpdated = onAddressUpdated;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView;
        if (viewType == TYPE_SHIPPING_ADDRESS) {
            itemView = LayoutInflater.from(context).inflate(R.layout.shipping_address, parent, false);
            return new ShippingAddressViewHolder(itemView);
        } else {
            itemView = LayoutInflater.from(context).inflate(R.layout.item_cart, parent, false);
            return new CartViewHolder(itemView);
        }

    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder1, int position) {

        if (getItemViewType(position) == TYPE_CART_ITEM) {
            cart = cartList.get(position);
            CartViewHolder holder = (CartViewHolder) holder1;
            holder.tvFoodName.setText(cart.getFoodName());
            holder.tvFoodPrice.setText((cart.getFoodPrice()) + " BDT");
            holder.tvCartItemCount.setText(cart.getQuantity() + "");
            // loading food cover image using Glide library
            Glide.with(context).load(cart.getFoodThumbnail()).into(holder.imgvFoodThumbnail);

            final int clickedPosition = position;

            holder.imgvCartItemPlus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int cartItemCount = cartList.get(clickedPosition).getQuantity();
                    Double foodPrice = cartList.get(clickedPosition).getFoodPrice();
                    Double singleFoodPrice = foodPrice / cartItemCount;
                    cart = cartList.get(clickedPosition);
                    cartItemCount = cartItemCount + 1;
                    foodPrice = singleFoodPrice * cartItemCount;
                    cart.setQuantity(cartItemCount);
                    cart.setFoodName(cartList.get(clickedPosition).getFoodName());
                    cart.setFoodPrice(foodPrice);
                    cart.setFoodThumbnail(cartList.get(clickedPosition).getFoodThumbnail());
                    cartList.set(clickedPosition, cart);
                    notifyItemChanged(clickedPosition);

                    cartList.remove(clickedPosition);
                    cartList.add(clickedPosition, cart);
                    utils.updateCart(cartList);
                }
            });

            holder.imgvCartItemMinus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int cartItemCount = cartList.get(clickedPosition).getQuantity();
                    Double foodPrice = cartList.get(clickedPosition).getFoodPrice();
                    Double singleFoodPrice = foodPrice / cartItemCount;
                    cart = cartList.get(clickedPosition);
                    if (cartItemCount > 1) {
                        cartItemCount = cartItemCount - 1;
                        foodPrice = singleFoodPrice * cartItemCount;
                        cart.setQuantity(cartItemCount);
                        cart.setFoodName(cartList.get(clickedPosition).getFoodName());
                        cart.setFoodPrice(foodPrice);
                        cart.setFoodThumbnail(cartList.get(clickedPosition).getFoodThumbnail());
                        cartList.set(clickedPosition, cart);
                        notifyItemChanged(clickedPosition);
                    }

                    cartList.remove(clickedPosition);
                    cartList.add(clickedPosition, cart);
                    utils.updateCart(cartList);
                }
            });
        } else {
            ShippingAddressViewHolder holder = (ShippingAddressViewHolder) holder1;
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    showInputDialog();

                }
            });
        }
    }

    protected void showInputDialog() {

        // get prompts.xml view
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View promptView = layoutInflater.inflate(R.layout.location_input, null);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
        alertDialogBuilder.setView(promptView);

        final EditText editText = (EditText) promptView.findViewById(R.id.edt_location);
        // setup a dialog window
        alertDialogBuilder.setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //  resultText.setText("Hello, " + editText.getText());
                        customerLocation = editText.getText().toString().trim();
                        if (customerLocation.isEmpty()){
                            Toast.makeText(context, "Please enter your shipping location.", Toast.LENGTH_SHORT).show();
                            return;
                        }else{
                            tvShippingAddress.setText(customerLocation);
                            onAddressUpdated.addressUpdated(customerLocation);
                        }
                    }
                })
                .setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });

        // create an alert dialog
        AlertDialog alert = alertDialogBuilder.create();
        alert.show();

    }

    @Override
    public int getItemViewType(int position) {
        return (position < cartList.size()) ? TYPE_CART_ITEM : TYPE_SHIPPING_ADDRESS;
    }

    @Override
    public int getItemCount() {
        return cartList.size() + 1;
    }

    private class ShippingAddressViewHolder extends RecyclerView.ViewHolder {

        public ShippingAddressViewHolder(View itemView) {
            super(itemView);
            tvShippingAddress = itemView.findViewById(R.id.tv_set_shipping_address);

        }
    }
}
