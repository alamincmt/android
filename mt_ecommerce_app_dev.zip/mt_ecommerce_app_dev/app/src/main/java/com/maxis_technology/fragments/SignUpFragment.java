package com.maxis_technology.fragments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.Response;
import com.maxis_technology.api.ApiWrapper;
import com.maxis_technology.commonutils.AlertDialogUtils;
import com.maxis_technology.commonutils.PreferenceData;
import com.maxis_technology.commonutils.Utils;
import com.maxis_technology.R;
import com.maxis_technology.activity.AuthenticationActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.LinkedHashMap;

public class SignUpFragment extends Fragment {

    private EditText et_customer_name, et_customer_email, et_customer_password, et_customer_phone, et_customer_address;
    private Button btn_save_customer;

    private String customerName, customerEmail, customerPhone, customerPassword, customerLocation;
    private Double latitude, longitute;
    private int cityId;
    private String customerPhoto;

    private Utils utils;
    private PreferenceData preferenceData;
    private Context context;
    private AlertDialogUtils alertDialogUtils;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        this.context = getActivity();
        this.utils = new Utils(getContext());
        this.preferenceData = new PreferenceData(context);
        this.alertDialogUtils = new AlertDialogUtils(getActivity());
        return inflater.inflate(R.layout.fragment_sign_up, container, false);

    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        btn_save_customer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getCustomerInfo();

               /* if(et_customer_name.getText().length() == 0 && et_customer_email.getText().length() == 0 &&
                et_customer_password.getText().length() ==0 && et_customer_phone.getText().length() == 0 &&
                et_customer_address.getText().length() == 0){
                    utils.showToastShort("Fill up all data first.");
               */
            if (customerName == null || customerName.isEmpty()){
                utils.showToastShort("Please put your name.");
                return;
            }else if (customerEmail == null || customerEmail.isEmpty()){
                utils.showToastShort("Please put your mail address.");
                return;
            }else if (customerPhone == null || customerPhone.isEmpty()){
                utils.showToastShort("Please put your phone no.");
                return;
            }else  if (customerPhone.length()<11){
                utils.showToastShort("Phone Number must be have 11 character.");
                return;
            }else if (customerLocation == null || customerLocation.isEmpty()){
                utils.showToastShort("Please put your address.");
                return;
            }else if (customerPassword == null || customerPassword.isEmpty()){
                utils.showToastShort("Please give a password as you can sign in next time.");
                return;
            }else  if (customerPassword.length()<6){
                utils.showToastShort("Password must be have 6 character.");
                return;
            }
            else{
                    alertDialogUtils.showProgressDialog(true);
                    LinkedHashMap<String, String> params = new LinkedHashMap<String, String>();

                    params.put("name", customerName);
                    params.put("phone", customerPhone);
                    params.put("email", customerEmail);
                    params.put("password", customerPassword);
                    params.put("location", customerLocation);
                    params.put("city_id", "100");

                    if(utils.isNetworkAvailable()){
                        new ApiWrapper(context).postNewCustomer(new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                Log.d("SignupResponse", response);
                                if(response != null && !response.equals("")){

                                    try {
                                        JSONObject rootJsonObject = new JSONObject(response.toString());
                                        int status = rootJsonObject.getInt("status");
                                        if(status == 200) {
                                            String message = rootJsonObject.getString("msg");
                                            JSONObject dataObj = rootJsonObject.getJSONObject("data");
                                            JSONObject customerJsonObj = dataObj.getJSONObject("customer");
                                            String authentication_key = customerJsonObj.getString("uuid");
                                            startActivity(new Intent(context, AuthenticationActivity.class).putExtra("fragment", "login"));
                                            utils.showToastLong("Registration Complete. You can login now.");
                                            alertDialogUtils.showProgressDialog(false);
                                        }else {
                                            utils.showToastLong(rootJsonObject.getString("errors"));
                                        }
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }

                                }
                            }
                        }, params);
                    }else{
                        utils.showToastLong("No network connection available!");
                    }
                }

            }
        });
    }

    private void getCustomerInfo(){
        customerName = et_customer_name.getText().toString().trim();
        customerEmail = et_customer_email.getText().toString().trim();
        customerPhone = et_customer_phone.getText().toString().trim();
        customerLocation = et_customer_address.getText().toString().trim();
        customerPassword = et_customer_password.getText().toString().trim();

    }

    private void initView(View view) {
        et_customer_name = (EditText) view.findViewById(R.id.et_customer_name);
        et_customer_email = (EditText) view.findViewById(R.id.et_customer_email);
        et_customer_password = (EditText) view.findViewById(R.id.et_customer_password);
        et_customer_phone = (EditText) view.findViewById(R.id.et_customer_phone);
        et_customer_address = (EditText) view.findViewById(R.id.et_customer_location);
        btn_save_customer = (Button) view.findViewById(R.id.btn_signup);
    }
}
