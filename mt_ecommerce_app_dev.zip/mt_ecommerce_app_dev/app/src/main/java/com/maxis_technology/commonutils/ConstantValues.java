package com.maxis_technology.commonutils;

public class ConstantValues {

    private ConstantValues(){

    }

    public final static String AUTHENTICATION_KEY = "auth_key";
    public final static String USER_NAME = "user_name";
    public static final String USER_ADDRESS = "user_address";
    public final static String USER_EMAIL = "user_email";
    public final static String USER_PHOTO = "user_photo";
    public static final String USER_PHONE = "user_phone";
}
