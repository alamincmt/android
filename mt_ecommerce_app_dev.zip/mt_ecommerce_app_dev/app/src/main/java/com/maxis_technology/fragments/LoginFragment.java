package com.maxis_technology.fragments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Response;
import com.maxis_technology.api.ApiWrapper;
import com.maxis_technology.callback.Communicator;
import com.maxis_technology.commonutils.AlertDialogUtils;
import com.maxis_technology.commonutils.Utils;
import com.maxis_technology.R;
import com.maxis_technology.activity.MainActivity;
import com.maxis_technology.commonutils.ConstantValues;
import com.maxis_technology.commonutils.PreferenceData;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.LinkedHashMap;

public class LoginFragment extends Fragment {
    private TextView txtSignUp;
    private EditText edtEmail, edtPassword;
    private Button btnLogIn;

    private PreferenceData preferenceData;
    private Utils utils;
    private Context context;
    private AlertDialogUtils alertDialogUtils;

    Communicator com;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        this.context = getActivity();
        this.utils = new Utils(context);
        this.preferenceData = new PreferenceData(context);
        this.alertDialogUtils = new AlertDialogUtils(getActivity());
        return  inflater.inflate(R.layout.fragment_sign_in, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initView(view);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        com = (Communicator) getActivity();

        btnLogIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = edtEmail.getText().toString().trim();
                String password = edtPassword.getText().toString().trim();
                if(email != null && !email.equals("") && password != null && !password.equals("")){
                    alertDialogUtils.showProgressDialog(true);
                    LinkedHashMap<String, String> params = new LinkedHashMap<String, String>();
                    params.put("email", email);
                    params.put("password", password);

                    if(utils.isNetworkAvailable()) {
                        new ApiWrapper(context).userLogin(new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                Log.d("loginResponse", response);
                                if (response != null && !response.equals("")) {
                                    try {
                                        JSONObject rootJsonObj = new JSONObject(response);
                                        int status = rootJsonObj.getInt("status");
                                        if (status == 200) {
                                            JSONObject dataJsonObj = rootJsonObj.getJSONObject("data");
                                            JSONObject userJsonObj = dataJsonObj.getJSONObject("user");
                                            String auth_key = userJsonObj.getString("auth_token");
                                            String name = userJsonObj.getString("name");
                                            String email = userJsonObj.getString("email");
                                            String photo = userJsonObj.getString("photo");
                                            String phone = userJsonObj.getString("phone");
                                            String address = userJsonObj.getString("location");
                                            preferenceData.setValue(ConstantValues.AUTHENTICATION_KEY, auth_key);
                                            preferenceData.setValue(ConstantValues.USER_NAME, name);
                                            preferenceData.setValue(ConstantValues.USER_EMAIL, email);
                                            preferenceData.setValue(ConstantValues.USER_PHOTO, photo);
                                            preferenceData.setValue(ConstantValues.USER_PHONE, phone);
                                            preferenceData.setValue(ConstantValues.USER_ADDRESS, address);
                                            startActivity(new Intent(getActivity(), MainActivity.class));
                                            alertDialogUtils.showProgressDialog(false);
                                        } else {
                                            utils.showToastLong(rootJsonObj.getString("errors"));
                                        }
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                }
                            }
                        }, params);
                    }else{
                        utils.showToastLong("No network connection available!");
                    }
                }else{
                    utils.showToastLong("Fill up data first. ");
                }
            }
        });

        txtSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                com.communicate("signup");
            }
        });
    }

    private void initView(View view) {
        edtEmail = (EditText) view.findViewById(R.id.et_email);
        edtPassword = (EditText) view.findViewById(R.id.et_password);
        btnLogIn = (Button) view.findViewById(R.id.btn_login);
        txtSignUp = (TextView) view.findViewById(R.id.txt_signup);
    }
}
