package com.maxis_technology.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.maxis_technology.commonutils.AlertDialogUtils;
import com.maxis_technology.R;
import com.maxis_technology.adapters.FoodAdapter;
import com.maxis_technology.commonutils.Utils;
import com.maxis_technology.model.CartItem;
import com.maxis_technology.model.FoodItem;

import java.util.ArrayList;
import java.util.List;

public class FoodDetailsActivity extends BaseActivity {

    String foodImage;
    TextView txtFoodName, txtFoodDetails, txtFoodPrice;
    Button btnAddToCart;
    ImageView detailCoverImage;
    Utils utils;
    FoodItem foodItem;
    AlertDialogUtils alertDialogUtils;
    private List<CartItem> mCart = new ArrayList<CartItem>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_details);
        utils = new Utils(this);
        alertDialogUtils = new AlertDialogUtils(this);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        init();
        Intent i = getIntent();
        foodItem = (FoodItem) i.getSerializableExtra("foodItem");
        foodImage = i.getStringExtra("foodImage");
       /* foodName = i.getStringExtra("foodNameToShowDetails");
        foodDetails = i.getStringExtra("foodDtails");
        foodImage = i.getStringExtra("foodImage");
        double food_price = i.getDoubleExtra("foodPrice",0.0);
        foodPrice = String.valueOf(food_price);
       */
        txtFoodName.setText(foodItem.getFoodName());
        txtFoodDetails.setText(foodItem.getFoodDetails());
        txtFoodPrice.setText(String.valueOf(foodItem.getFoodPrice()));

        if ( foodItem.getFoodThumbnail() == null || foodItem.getFoodThumbnail().isEmpty()){
            detailCoverImage.setImageResource(R.drawable.food_image5);
        }else {
           // detailCoverImage.setImageURI(Uri.parse(foodImage));
            utils.loadImageThumbnail(this,detailCoverImage, foodItem.getFoodThumbnail());
        }

        btnAddToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                alertDialogUtils.showAddToCartItemChooserDialog(foodItem.getFoodName(), new FoodAdapter.OnCartItemCountChanged() {
                    @Override
                    public void onChange(int newCount) {
                        mCart = utils.getCartItems();
                        if (mCart == null) {
                            mCart = new ArrayList<CartItem>();
                        }

//                        CartItem cartItem = (CartItem) foodItem; // BARI KHAY KEN? :@
                        CartItem cartItem = new CartItem(foodItem);
                        cartItem.setQuantity(newCount)
                                .setFoodPrice(foodItem.getFoodPrice() * newCount);

                        mCart.add(cartItem);

                        utils.updateCart(mCart);
                    }
                });

            }
        });
    }

    public void init(){
        txtFoodDetails = (TextView) findViewById(R.id.tv_food_details);
        txtFoodName = (TextView) findViewById(R.id.tv_food_name);
        txtFoodPrice = (TextView) findViewById(R.id.tv_food_price_detail);
        btnAddToCart = (Button) findViewById(R.id.btn_food_details_add_to_cart);
       detailCoverImage = (ImageView) findViewById(R.id.detail_cover_image);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
