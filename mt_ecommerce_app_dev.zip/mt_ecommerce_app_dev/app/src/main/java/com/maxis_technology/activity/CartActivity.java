package com.maxis_technology.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.Response;
import com.maxis_technology.R;
import com.maxis_technology.adapters.CartAdapter;
import com.maxis_technology.api.ApiWrapper;
import com.maxis_technology.commonutils.AlertDialogUtils;
import com.maxis_technology.commonutils.Utils;
import com.maxis_technology.model.CartItem;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

public class CartActivity extends BaseActivity {

    private Context context;
    private RecyclerView rvCart;
    private List<CartItem> cartList = new ArrayList<CartItem>();
    private int[] foodThumnails;
    private CartAdapter cartAdapter;
    private Utils utils;
    private String customerLocation = null;
    private Button btnConfirmCartOrder;
    private SwipeRefreshLayout swipeRefreshLayoutCartList;
    private AlertDialogUtils alertDialogUtils;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.context = CartActivity.this;
        this.utils = new Utils(context);
        this.alertDialogUtils = new AlertDialogUtils(CartActivity.this);
        setContentView(R.layout.activity_add_to_cart);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        prepareAddToCartData();
        rvCart = (RecyclerView) findViewById(R.id.rcv_add_to_cart);
        swipeRefreshLayoutCartList = (SwipeRefreshLayout) findViewById(R.id.swipe_refresh_cart_list);
        btnConfirmCartOrder = (Button) findViewById(R.id.btn_confirm_order);
        if(cartList != null && cartList.size()>0){
            cartAdapter = new CartAdapter(context, cartList, new OnAddressUpdated(){
                @Override
                public void addressUpdated(String address) {
                    customerLocation = address;
                }
            });
            RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(context);
            rvCart.setLayoutManager(layoutManager);
            rvCart.setItemAnimator(new DefaultItemAnimator());
            rvCart.setAdapter(cartAdapter);
            cartAdapter.notifyDataSetChanged();
        }

        swipeRefreshLayoutCartList.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if(cartList != null && cartList.size()>0){
                    cartAdapter = new CartAdapter(context, cartList, new OnAddressUpdated(){
                        @Override
                        public void addressUpdated(String address) {
                            customerLocation = address;
                        }
                    });
                    RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(context);
                    rvCart.setLayoutManager(layoutManager);
                    rvCart.setItemAnimator(new DefaultItemAnimator());
                    rvCart.setAdapter(cartAdapter);
                    cartAdapter.notifyDataSetChanged();
                    swipeRefreshLayoutCartList.setRefreshing(false);
                }
            }
        });

        ItemTouchHelper.SimpleCallback itemTouchHelperTouchCallBack = new ItemTouchHelper.SimpleCallback(0,
                ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
//                Toast.makeText(CartActivity.this, "Item Moved", Toast.LENGTH_SHORT).show();
                return false;
            }

            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                cartList.remove(viewHolder.getAdapterPosition());
                cartAdapter.notifyDataSetChanged();
                utils.updateCart(cartList);
                Toast.makeText(CartActivity.this, "Item deleted from cart.", Toast.LENGTH_SHORT).show();
            }
        };

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(itemTouchHelperTouchCallBack);
        itemTouchHelper.attachToRecyclerView(rvCart);


        // Back button added in the actionbar.
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        btnConfirmCartOrder.setOnClickListener(new View.OnClickListener() {

           // LinkedHashMap<String, String> params = new LinkedHashMap<String, String>();

            @Override
            public void onClick(View view) {

                if (cartList== null || cartList.size() == 0){
                    Toast.makeText(context, "Make sure that you add some item on cart.", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (customerLocation == null || customerLocation.isEmpty()) {
                    Toast.makeText(context, "Please choose your shipping address!", Toast.LENGTH_SHORT).show();
                    return;
                }

                LinkedHashMap<String, String> params = new LinkedHashMap<String, String>();
                context = CartActivity.this;
                utils = new Utils(context);
                cartList = utils.getCartItems();
                params.put("delivery_address", customerLocation);

                if(cartList != null) {
                    for (int i = 0; i < cartList.size(); i++) {
                        params.put("foods[id][" + i + "]", cartList.get(i).getFoodId());
                        params.put("foods[qty][" + i + "]", String.valueOf(cartList.get(i).getQuantity()));
                    }
                }

                if(utils.isNetworkAvailable()) {
                    alertDialogUtils.showProgressDialog(true);
                    new ApiWrapper(context).postOrder(new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            Intent intent = new Intent("receive_cart_item_count");
                            intent.putExtra("itemCount", 0);
                            LocalBroadcastManager.getInstance(CartActivity.this).sendBroadcast(intent);
                            startActivity(new Intent(context, OrderSuccessfullActivity.class));

                            utils.clearCartItems();
                            cartList.clear();
                            alertDialogUtils.showProgressDialog(false);
                            cartAdapter.notifyDataSetChanged();
                        }
                    }, params);

                }else{
                    utils.showToastLong("No network connection available!");
                }
            }
        });
    }

    private void prepareAddToCartData() {
        cartList = utils.getCartItems();
    }


    @Override
    protected void onPause() {
        alertDialogUtils.showProgressDialog(false);
        finish();
        super.onPause();
    }
    @Override
    protected void onStop() {
        alertDialogUtils.showProgressDialog(false);
        super.onStop();
    }

    @Override
    protected void onResume() {
        alertDialogUtils.showProgressDialog(false);
        if(cartAdapter != null)
        cartAdapter.notifyDataSetChanged();
        super.onResume();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    public interface OnAddressUpdated{
        void addressUpdated(String address);
    }

}
