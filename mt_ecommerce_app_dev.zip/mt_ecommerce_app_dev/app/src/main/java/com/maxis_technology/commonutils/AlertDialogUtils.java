package com.maxis_technology.commonutils;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.maxis_technology.R;
import com.maxis_technology.adapters.FoodAdapter;

public class AlertDialogUtils {

    private Activity activity;
    private AlertDialog.Builder alertDialogBuilder;
    private LayoutInflater inflater;
    private View view;
    private Utils utils;
    ProgressDialog progressDialog;
    private AlertDialog alertDialog;
    int count = 1;
    public AlertDialogUtils() {}

    public AlertDialogUtils(Activity activity) {
        this.activity = activity;
        utils = new Utils(activity);
        progressDialog = new ProgressDialog(activity);
    }

    public void showProgressDialog(boolean show){
        progressDialog.setMessage("Please wait...");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        if(show){
            progressDialog.show();
        }else{
            progressDialog.dismiss();
        }
    }

    public void showAddToCartItemChooserDialog(String title, final FoodAdapter.OnCartItemCountChanged onCartItemCountChanged){
        count = 1;
        alertDialogBuilder = new AlertDialog.Builder(activity);
        inflater = activity.getLayoutInflater();
        view = inflater.inflate(R.layout.custom_dialog_layout_for_add_to_cart, null);
        ImageView imgvItemPlus = (ImageView) view.findViewById(R.id.imv_plus_item);
        ImageView  imgvItemMinus = (ImageView) view.findViewById(R.id.imv_minus_item);
        final TextView tvCartItemCount = (TextView) view.findViewById(R.id.tv_cart_item_cout);
        imgvItemPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvCartItemCount.setText(" " + ++count);
            }
        });
        imgvItemMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(count > 1)
                tvCartItemCount.setText(" " + --count);
            }
        });
        Button btnAdd = (Button) view.findViewById(R.id.btn_add_cart_item);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                utils.showToastShort("Item added");
                onCartItemCountChanged.onChange(count);
                alertDialog.dismiss();

            }
        });
        alertDialogBuilder.setTitle(title);
        alertDialogBuilder.setView(view);
        alertDialogBuilder.setCancelable(true);

        alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    public void showNormalDialog(Context context,String massage,String positiveButtonText, String negativeButtonText){

    }

}
