package com.maxis_technology.commonutils;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.widget.ImageView;
import android.widget.Toast;

import com.maxis_technology.R;
import com.maxis_technology.model.CartItem;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.List;

public class Utils {
    private Context context;

    public Utils(Context context){
        this.context = context;
    }

    public void showToastShort(String message){
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }

    public void showToastLong(String message){
        Toast.makeText(context, message, Toast.LENGTH_LONG).show();
    }

    public void loadImageThumbnail(Context context, ImageView imageView, String url){
        Glide.with(context).load(url).placeholder(R.drawable.food_image5).into(imageView);
    }
    public void loadImage(Context context, ImageView imageView,int url){
        Glide.with(context).load(url).into(imageView);
    }

    public void updateCart(List<CartItem> items){
        SharedPreferences sp = context.getSharedPreferences("BK_CART_STORAGE", Context.MODE_PRIVATE);
        new Gson().toJson(items);
        String json = new Gson().toJson(items);
        sp.edit().putString("BK_CART_ITEMS",json).commit();
    }

    public List<CartItem> getCartItems(){
        SharedPreferences sp = context.getSharedPreferences("BK_CART_STORAGE", Context.MODE_PRIVATE);
        String json = sp.getString("BK_CART_ITEMS",null);
        if (json != null) {
            return new Gson().fromJson(json,new TypeToken<List<CartItem>>() {}.getType());
        }
        return null;
    }

    public void clearCartItems(){
        SharedPreferences sp = context.getSharedPreferences("BK_CART_STORAGE",Context.MODE_PRIVATE);
        sp.edit().clear().apply();
    }

    public boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }
}
