package com.example.mdal_amin.firstmvp;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.mdal_amin.firstmvp.interfaces.SignUpActivityView;
import com.example.mdal_amin.firstmvp.presenter.SignUpActivityPresenter;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.GoogleApiClient;

import java.util.HashMap;

import static com.example.mdal_amin.firstmvp.R.id.btnRegister;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, SignUpActivityView{


    private Button btnRegister, btnSignIn;

    private EditText etNickName, etFullName, etMobileNumber;
    private RadioGroup rdUserType;
    private RadioButton rdSingleType;
    private String nickName, fullName, username;
    private int userType = 0;
    private ProgressBar progressBar;
    private SignUpActivityPresenter presenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        presenter = new SignUpActivityPresenter(this);
        btnRegister = (Button) findViewById(R.id.btnRegister);
        btnSignIn = (Button) findViewById(R.id.btnSignIn);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        etNickName = (EditText) findViewById(R.id.etNickName);
        etFullName = (EditText) findViewById(R.id.etFullName);
        etMobileNumber = (EditText) findViewById(R.id.etMobileNumber);

        rdUserType = (RadioGroup) findViewById(R.id.rdUserType);

        btnRegister.setOnClickListener(this);
        btnSignIn.setOnClickListener(this);

        rdUserType.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                // get selected radio button from radioGroup
                int selectedId = rdUserType.getCheckedRadioButtonId();

                // find the radiobutton by returned id
                rdSingleType = (RadioButton) findViewById(i);
                String user = rdSingleType.getText().toString().trim();

                if(null != user && user.equals("Patient")){
                    userType = 1;
                }else if (null != user && user.equals("Caregiver")){
                    userType = 2;
                }else if (null != user && user.equals("Doctor")){
                    userType = 3;
                }
            }
        });

    }

    @Override
    public void onClick(View view) {
        int id = view.getId();

        switch (id) {
            case R.id.btnRegister:
                postRegistrationData();
                //gotoVerifyPhoneNo();
                break;
            case R.id.btnSignIn:
                gotoLoginActivity();
                break;
        }
    }

    private void gotoLoginActivity() {
        //startActivity(new Intent(this, LoginActivity.class));
    }

    private void postRegistrationData() {
        nickName = etNickName.getText().toString().trim();
        fullName = etFullName.getText().toString().trim();
        username = etMobileNumber.getText().toString().trim();

        if(nickName != "" && nickName != null && fullName != "" && fullName != null && username != "" && username != null && userType != 0) {
            HashMap params = new HashMap();
            params.put("username", username);
            params.put("nickName", nickName);
            params.put("fullName", fullName);
            params.put("userType", userType + "");
            presenter.registerUser(params);
        } else {
            showMessage("Please Fill up all information & try Again");
        }
    }

    @Override
    public void startLoading() {
        progressBar.setVisibility(View.VISIBLE);
    }

    @Override
    public void stopLoading() {
        progressBar.setVisibility(View.GONE);
    }

    @Override
    public Context getAppContext() {
        return MainActivity.this;
    }

    @Override
    public void showMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public Application getPresentApplication() {
        return getApplication();
    }

    @Override
    public void ApplicationFinish() {
        finish();
    }
}
