package com.example.mdal_amin.firstmvp.utils;

public class ConstantValues {
    public final static String URL = "http://52.220.160.233/diarobo/api/v1/";
    public final static String MY_URL = "http://favouritesoft.com/registration.php";
    public final static String registrationMethodName = "registration";
    public final static String phoneVerificationMethodName = "phoneVerification";
    public final static String resendVerificationCodeMethodName = "reSendVerificationCode";
    public final static String loginMethodName = "login";

}
