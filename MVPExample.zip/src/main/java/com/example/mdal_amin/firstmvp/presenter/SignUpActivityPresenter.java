package com.example.mdal_amin.firstmvp.presenter;

import android.content.Intent;


import com.example.mdal_amin.firstmvp.interfaces.OnRequestComplete;
import com.example.mdal_amin.firstmvp.interfaces.SignUpActivityView;
import com.example.mdal_amin.firstmvp.model.SIgnUpApi;
import com.example.mdal_amin.firstmvp.utils.ConstantValues;

import java.util.HashMap;

/**
 * Created by rakib on 12/10/2016.
 */

public class SignUpActivityPresenter {
    SignUpActivityView view;

    public SignUpActivityPresenter(SignUpActivityView view ) {
        this.view = view;
    }


    public void registerUser(HashMap params){
        view.startLoading();
        new SIgnUpApi(ConstantValues.registrationMethodName, params, view.getAppContext(), new OnRequestComplete() {
            @Override
            public void onRequestComplete(Object infoData) {
                view.stopLoading();
                HashMap result = (HashMap) infoData;
                boolean hasError;
                hasError = Boolean.parseBoolean(result.get("hasError").toString());
                if(!hasError) {
                    //Intent intent = new Intent(view.getAppContext(), PhoneVerificationActivity.class);
                    //intent.putExtra("USER_NAME", result.get("username").toString());
                    //intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    //view.getPresentApplication().startActivity(intent);
                   view.ApplicationFinish();
                } else {
                    view.showMessage(result.get("errorMsg").toString());
                }
            }
            @Override
            public void onRequestError(String errorMsg) {
                view.stopLoading();
                view.showMessage(errorMsg);
            }
        });
    }
}
