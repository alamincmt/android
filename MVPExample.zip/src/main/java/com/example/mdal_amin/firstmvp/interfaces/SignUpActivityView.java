package com.example.mdal_amin.firstmvp.interfaces;

import android.app.Application;
import android.content.Context;

/**
 * Created by Al-Amin on 12/10/2016.
 */

public interface SignUpActivityView {
    public void startLoading();
    public void stopLoading();
    Context getAppContext();
    public void showMessage(String message);
    public Application getPresentApplication();
    public void ApplicationFinish();
}
