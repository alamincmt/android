package com.example.mdal_amin.firstmvp.model;

import android.content.Context;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.mdal_amin.firstmvp.interfaces.OnRequestComplete;
import com.example.mdal_amin.firstmvp.utils.ConstantValues;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class SIgnUpApi {
    OnRequestComplete requestComplete;

    public SIgnUpApi(final String methodName, final HashMap userRegistrationInfo, final Context context, final OnRequestComplete onRequestComplete) {
        this.requestComplete = onRequestComplete;

        RequestQueue queue = Volley.newRequestQueue(context);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, ConstantValues.URL + methodName,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            HashMap hashMap = new HashMap();
                            hashMap.put("errorMsg", jsonObject.getString("errorMsg"));
                            hashMap.put("hasError", jsonObject.getString("hasError"));
                            String username = null;
                            String userType = null;
                            try {
                                username = jsonObject.getString("username");
                            } catch (Exception e) {

                            }
                            try {
                                userType = jsonObject.getString("userType");
                            } catch (Exception e) {

                            }
                            if(username != null ){
                                hashMap.put("username", jsonObject.getString("username"));
                            }
                            if(userType != null ){
                                hashMap.put("userType", jsonObject.getString("userType"));
                            }
                            requestComplete.onRequestComplete(hashMap);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                requestComplete.onRequestError("Something went wrong.");
            }
        }){
            @Override
            protected Map<String, String> getParams()
            {
                return userRegistrationInfo;
            }
        };

        // Add the request to the RequestQueue.
        queue.add(stringRequest);
    }
}
