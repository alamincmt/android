package com.example.mdal_amin.firstmvp.interfaces;

public interface OnRequestComplete {
    void onRequestComplete(Object o);
    void onRequestError(String errorMsg);
}
