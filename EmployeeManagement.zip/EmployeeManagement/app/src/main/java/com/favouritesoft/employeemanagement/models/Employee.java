package com.favouritesoft.employeemanagement.models;

/**
 * Created by itsmd on 01-Aug-17.
 */

public class Employee {
    private long empId;
    private String empFirstName;
    private String empLastName;
    private String empGender;
    private String empHireDate;
    private String empDept;

    public Employee(long empId, String empFirstName, String empLastName, String empGender, String empHireDate, String empDept){
        this.empId = empId;
        this.empFirstName = empFirstName;
        this.empLastName = empLastName;
        this.empGender = empGender;
        this.empHireDate = empHireDate;
        this.empDept = empDept;
    }

    public Employee(){}

    public long getEmpId() {
        return empId;
    }

    public void setEmpId(long empId) {
        this.empId = empId;
    }

    public String getEmpFirstName() {
        return empFirstName;
    }

    public void setEmpFirstName(String empFirstName) {
        this.empFirstName = empFirstName;
    }

    public String getEmpLastName() {
        return empLastName;
    }

    public void setEmpLastName(String empLastName) {
        this.empLastName = empLastName;
    }

    public String getEmpGender() {
        return empGender;
    }

    public void setEmpGender(String empGender) {
        this.empGender = empGender;
    }

    public String getEmpHireDate() {
        return empHireDate;
    }

    public void setEmpHireDate(String empHireDate) {
        this.empHireDate = empHireDate;
    }

    public String getEmpDept() {
        return empDept;
    }

    public void setEmpDept(String empDept) {
        this.empDept = empDept;
    }

    public String toString(){
        return "EmpId: " + getEmpId() + "\n" +
                "Emp Name: " + getEmpFirstName() + " " + getEmpLastName() + "\n" +
                "Emp Gender: " + getEmpGender() + "\n" +
                "Emp Hire Date: " + getEmpHireDate() + "\n" +
                "Emp Dept: " + getEmpDept();
    }
}
