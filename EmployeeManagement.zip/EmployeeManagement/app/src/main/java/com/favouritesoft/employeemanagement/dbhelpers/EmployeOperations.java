package com.favouritesoft.employeemanagement.dbhelpers;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.favouritesoft.employeemanagement.models.Employee;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by itsmd on 01-Aug-17.
 */

public class EmployeOperations {

    private static final String LOG_TAG = "EMP_MNGMNT_SYS";

    SQLiteOpenHelper sqLiteOpenHelper;
    SQLiteDatabase sqLiteDatabase;

    private static final String[] allColumns = {
            EmployeDBHelper.COLUMN_ID,
            EmployeDBHelper.COLUMN_FIRST_NAME,
            EmployeDBHelper.COLUMN_LAST_NAME,
            EmployeDBHelper.COLUMN_GENDER,
            EmployeDBHelper.COLUMN_HIRE_DATE,
            EmployeDBHelper.COLUMN_DEPT
    };

    public EmployeOperations(Context context) {
        sqLiteOpenHelper = new EmployeDBHelper(context);
    }

    public void open(){
        Log.d(LOG_TAG, "Database Opened");
        sqLiteDatabase = sqLiteOpenHelper.getWritableDatabase();
    }

    public void close(){
        Log.d(LOG_TAG, "Database Closed");
        sqLiteOpenHelper.close();
    }

    public Employee addEmployee(Employee employee) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(EmployeDBHelper.COLUMN_FIRST_NAME, employee.getEmpFirstName());
        contentValues.put(EmployeDBHelper.COLUMN_LAST_NAME, employee.getEmpLastName());
        contentValues.put(EmployeDBHelper.COLUMN_GENDER, employee.getEmpGender());
        contentValues.put(EmployeDBHelper.COLUMN_HIRE_DATE, employee.getEmpHireDate());
        contentValues.put(EmployeDBHelper.COLUMN_DEPT, employee.getEmpDept());
        long insertId = sqLiteDatabase.insert(EmployeDBHelper.TABLE_EMPLOYEES, null, contentValues);
        employee.setEmpId(insertId);
        return employee;
    }

    // Getting Single Employee
    public Employee getEmployee(long empId){
        Cursor cursor = sqLiteDatabase.query(EmployeDBHelper.TABLE_EMPLOYEES, allColumns, EmployeDBHelper.COLUMN_ID + "=?", new String[]{String.valueOf(empId)}, null, null, null);
        Employee employee = null;
        if(cursor != null) {
            cursor.moveToFirst();
            employee = new Employee(Long.parseLong(cursor.getString(0)), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getString(5));
            return employee;
        }else {
            Log.d(LOG_TAG, "Emp Not Found");
        }
        return employee;
    }

    public List<Employee> getAllEmployees(){
        List<Employee> employeeList = new ArrayList<Employee>();
        Cursor cursor = sqLiteDatabase.query(EmployeDBHelper.TABLE_EMPLOYEES, allColumns, null, null, null, null, null, null);
        if (cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                Employee employee = new Employee();
                employee.setEmpId(cursor.getLong(cursor.getColumnIndex(EmployeDBHelper.COLUMN_ID)));
                employee.setEmpFirstName(cursor.getString(cursor.getColumnIndex(EmployeDBHelper.COLUMN_FIRST_NAME)));
                employee.setEmpLastName(cursor.getString(cursor.getColumnIndex(EmployeDBHelper.COLUMN_LAST_NAME)));
                employee.setEmpGender(cursor.getString(cursor.getColumnIndex(EmployeDBHelper.COLUMN_GENDER)));
                employee.setEmpHireDate(cursor.getString(cursor.getColumnIndex(EmployeDBHelper.COLUMN_HIRE_DATE)));
                employee.setEmpDept(cursor.getString(cursor.getColumnIndex(EmployeDBHelper.COLUMN_DEPT)));
                employeeList.add(employee);
            }
        }
        return employeeList;
    }

    // Updating employee
    public int updateEmployee(Employee employee) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(EmployeDBHelper.COLUMN_FIRST_NAME, employee.getEmpFirstName());
        contentValues.put(EmployeDBHelper.COLUMN_LAST_NAME, employee.getEmpLastName());
        contentValues.put(EmployeDBHelper.COLUMN_GENDER, employee.getEmpGender());
        contentValues.put(EmployeDBHelper.COLUMN_HIRE_DATE, employee.getEmpHireDate());
        contentValues.put(EmployeDBHelper.COLUMN_DEPT, employee.getEmpDept());
        return sqLiteDatabase.update(EmployeDBHelper.TABLE_EMPLOYEES, contentValues, EmployeDBHelper.COLUMN_ID + "=?", new String[]{String.valueOf(employee.getEmpId())});
    }

    // Remove employee from database
    public void removeEmployee(Employee employee) {
        sqLiteDatabase.delete(EmployeDBHelper.TABLE_EMPLOYEES, EmployeDBHelper.COLUMN_ID + "=" + employee.getEmpId(), null);
    }

}
