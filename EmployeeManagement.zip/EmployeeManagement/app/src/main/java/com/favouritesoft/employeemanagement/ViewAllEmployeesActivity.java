package com.favouritesoft.employeemanagement;

import android.app.ListActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;

import com.favouritesoft.employeemanagement.dbhelpers.EmployeOperations;
import com.favouritesoft.employeemanagement.models.Employee;

import java.util.List;

public class ViewAllEmployeesActivity extends ListActivity {
    private EmployeOperations employeeOps;
    List<Employee> employees;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_all_employees);
        employeeOps = new EmployeOperations(this);
        if(employeeOps != null)
        employeeOps.open();
        employees = employeeOps.getAllEmployees();
        if(employeeOps != null)
        employeeOps.close();
        ArrayAdapter<Employee> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, employees);
        setListAdapter(adapter);
    }
}
