package com.favouritesoft.employeemanagement;

import android.content.Intent;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.favouritesoft.employeemanagement.dbhelpers.EmployeDBHelper;
import com.favouritesoft.employeemanagement.dbhelpers.EmployeOperations;
import com.favouritesoft.employeemanagement.models.Employee;
import com.favouritesoft.employeemanagement.utils.DatePickerFragment;

import java.text.SimpleDateFormat;
import java.util.Date;

public class AddUpdateActivity extends AppCompatActivity implements DatePickerFragment.DateDialogListener{

    private static final String EXTRA_EMP_ID = "empId";
    private static final String EXTRA_ADD_UPDATE = "add_update";
    private static final String DIALOG_DATE = "DialogDate";
    private ImageView calendarImage;
    private RadioGroup radioGroup;
    private RadioButton maleRadioButton,femaleRadioButton;
    private EditText firstNameEditText;
    private EditText lastNameEditText;
    private EditText deptEditText;
    private EditText hireDateEditText;
    private Button addUpdateButton;
    private Employee newEmployee;
    private Employee oldEmployee;
    private String mode;
    private long empId;
    private EmployeOperations employeeOperations;
    private String empGender = "M";
    EmployeDBHelper employeDBHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_update);

        employeDBHelper = new EmployeDBHelper(this);

        newEmployee = new Employee();
        oldEmployee = new Employee();
        firstNameEditText = (EditText)findViewById(R.id.edit_text_first_name);
        lastNameEditText = (EditText)findViewById(R.id.edit_text_last_name);
        hireDateEditText = (EditText) findViewById(R.id.edit_text_hire_date);
        radioGroup = (RadioGroup) findViewById(R.id.radio_gender);
        maleRadioButton = (RadioButton) findViewById(R.id.radio_male);
        femaleRadioButton = (RadioButton) findViewById(R.id.radio_female);
        calendarImage = (ImageView)findViewById(R.id.image_view_hire_date);
        deptEditText = (EditText)findViewById(R.id.edit_text_dept);
        addUpdateButton = (Button)findViewById(R.id.button_add_update_employee);
        employeeOperations = new EmployeOperations(this);
        if(employeeOperations != null)
            employeeOperations.open();


        mode = getIntent().getStringExtra(EXTRA_ADD_UPDATE);
        if(mode.equals("Update")){

            addUpdateButton.setText("Update Employee");
            empId = getIntent().getLongExtra(EXTRA_EMP_ID,0);

            initializeEmployee(empId);

        }

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                // find which radio button is selected
                if (checkedId == R.id.radio_male) {
                    empGender = "M";
                    if(mode.equals("Update")){
                        empGender = "M";
                    }
                } else if (checkedId == R.id.radio_female) {
                    empGender = "F";
                    if(mode.equals("Update")){
                        empGender = "F";
                    }
                }
            }

        });

        calendarImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                FragmentManager manager = getSupportFragmentManager();
                DatePickerFragment dialog = new DatePickerFragment();
                dialog.show(manager, DIALOG_DATE);
            }
        });


        addUpdateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(mode.equals("Add")) {
                    newEmployee.setEmpFirstName(firstNameEditText.getText().toString());
                    newEmployee.setEmpLastName(lastNameEditText.getText().toString());
                    newEmployee.setEmpHireDate(hireDateEditText.getText().toString());
                    newEmployee.setEmpGender(empGender);
                    newEmployee.setEmpDept(deptEditText.getText().toString());
                    employeeOperations.addEmployee(newEmployee);
                    Toast t = Toast.makeText(AddUpdateActivity.this, "Employee "+ newEmployee.getEmpFirstName() + "has been added successfully !", Toast.LENGTH_SHORT);
                    t.show();
                    Intent i = new Intent(AddUpdateActivity.this, MainActivity.class);
                    startActivity(i);
                }else {
                    oldEmployee.setEmpFirstName(firstNameEditText.getText().toString());
                    oldEmployee.setEmpLastName(lastNameEditText.getText().toString());
                    oldEmployee.setEmpHireDate(hireDateEditText.getText().toString());
                    newEmployee.setEmpGender(empGender);
                    oldEmployee.setEmpDept(deptEditText.getText().toString());
                    employeeOperations.updateEmployee(oldEmployee);
                    Toast t = Toast.makeText(AddUpdateActivity.this, "Employee "+ oldEmployee.getEmpFirstName() + " has been updated successfully !", Toast.LENGTH_SHORT);
                    t.show();
                    Intent i = new Intent(AddUpdateActivity.this,MainActivity.class);
                    startActivity(i);

                }


            }
        });
    }

    private void initializeEmployee(long empId) {
        oldEmployee = employeeOperations.getEmployee(empId);
        firstNameEditText.setText(oldEmployee.getEmpFirstName());
        lastNameEditText.setText(oldEmployee.getEmpLastName());
        hireDateEditText.setText(oldEmployee.getEmpHireDate());
        radioGroup.check(oldEmployee.getEmpGender().equals("M") ? R.id.radio_male : R.id.radio_female);
        deptEditText.setText(oldEmployee.getEmpDept());
    }


    @Override
    public void onFinishDialog(Date date) {
        hireDateEditText.setText(formatDate(date));

    }

    public String formatDate(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String hireDate = sdf.format(date);
        return hireDate;
    }
}
