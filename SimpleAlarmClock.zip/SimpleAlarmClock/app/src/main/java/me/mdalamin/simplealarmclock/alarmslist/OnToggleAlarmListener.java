package me.mdalamin.simplealarmclock.alarmslist;

import me.mdalamin.simplealarmclock.data.Alarm;

public interface OnToggleAlarmListener {
    void onToggle(Alarm alarm);
}
