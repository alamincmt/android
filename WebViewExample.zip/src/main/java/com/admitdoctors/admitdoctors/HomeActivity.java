package com.admitdoctors.admitdoctors;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class HomeActivity extends Activity {

    // Declaring Webview to load url http://admitdoctors.com/
    private WebView webViewAdmitDoct;
    private final String admitDoctUrl = "http://admitdoctors.com/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        webViewAdmitDoct = (WebView) findViewById(R.id.wvAdmitDoct); // Initializing webview
        webViewAdmitDoct.loadUrl(admitDoctUrl);
        WebSettings webSettings = webViewAdmitDoct.getSettings(); // getting websettings
        webSettings.setJavaScriptEnabled(true);
        webSettings.setBuiltInZoomControls(true);
        webSettings.setDisplayZoomControls(true);
        webSettings.setRenderPriority(WebSettings.RenderPriority.HIGH);
        webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        webSettings.setDomStorageEnabled(true);
        webSettings.setDatabaseEnabled(true);
        webSettings.setAppCacheEnabled(true);

        webViewAdmitDoct.setFocusable(true);
        webViewAdmitDoct.setFocusableInTouchMode(true);
        webViewAdmitDoct.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);


        // Force links and redirects to open in the WebView instead of in a browser
        webViewAdmitDoct.setWebViewClient(new CustomWebViewClient(HomeActivity.this));

        //webViewAdmitDoct.addJavascriptInterface(new WebAppInterface(this), "Android");

        /*if (savedInstanceState != null)
            ((WebView)findViewById(R.id.wvAdmitDoct)).restoreState(savedInstanceState);
        else
            webViewAdmitDoct.loadUrl(admitDoctUrl);*/

    }

    // method for save instance on orientation change
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webViewAdmitDoct.saveState(outState);
    }

    // methods for key back press
    @Override
    public void onBackPressed() {
        if(webViewAdmitDoct.canGoBack()) {
            webViewAdmitDoct.goBack();
        } else {
            super.onBackPressed();
        }
    }

    /*@Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // Check if the key event was the Back button and if there's history
        if ((keyCode == KeyEvent.KEYCODE_BACK) && webViewAdmitDoct.canGoBack()) {
            webViewAdmitDoct.goBack();
            return true;
        }
        // If it wasn't the Back key or there's no web page history, bubble up to the default
        // system behavior (probably exit the activity)
        return super.onKeyDown(keyCode, event);
    }*/

    // This class is for Android Web Interface
    public class WebAppInterface {
        Context mContext;

        /** Instantiate the interface and set the context */
        WebAppInterface(Context c) {
            mContext = c;
        }

        /** Show a toast from the web page */
        @JavascriptInterface
        public void showToast(String toast) {
            Toast.makeText(mContext, toast, Toast.LENGTH_SHORT).show();
        }
    }

}

