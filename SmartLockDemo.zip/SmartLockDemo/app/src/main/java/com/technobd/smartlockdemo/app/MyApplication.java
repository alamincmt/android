package com.technobd.smartlockdemo.app;

import android.app.Application;

import com.pixplicity.easyprefs.library.Prefs;

/**
 * Created by user on 11/7/17.
 */

public class MyApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        new Prefs.Builder()
                .setContext(this)
                .setMode(MODE_PRIVATE)
                .setPrefsName(getPackageName())
                .setUseDefaultSharedPreference(true)
                .build();

    }
}
